/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

/*
    Sigue esforzandote!
    
    NOTAS:
    1. no se puede modificar el codigo del lugar.
    2. no puede un albergue convertirse en centro de acopio, ni viceversa.
 */
public class Grafo{
    
    private static Grafo grafo = null;

    public static Grafo getGrafo() {
        synchronized(Grafo.class){
            if(grafo == null){
                grafo = new Grafo();
            }
        }
        return grafo;
    }    
    
    ArrayList<NodoGrafo> nodos;

    public Grafo( ) {
        this.nodos = new ArrayList<>();
    }
    
    /*----------------------------------------------------------------------------------------------------------------*/        
    
    public String obtenerJson(String codigo,String password){
        String json = "no";
        NodoGrafo busqueda = buscarNodo(codigo);
        if (busqueda!=null && busqueda.obtenerPassword().equals(password)) {
            json = "";
            File fichero = new File("C:\\Users\\ebp\\Documents\\NetBeansProjects\\P2Servidor\\build\\web\\fonts\\"+busqueda.archivo);
            Scanner s = null;
            try {
                s = new Scanner(fichero);
                while(s.hasNextLine()){
                    json += s.nextLine()+"\n";
                }
            } catch (FileNotFoundException e) {
                System.out.println(e.getMessage());
            }finally{
                try {
                    if(s!=null)
                        s.close();
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
            }
        }
        return json;
    }
    
    public void preLocalidad(String codigo,String password,String json){
        System.out.println(codigo);
        System.out.println(password);
        System.out.println(json);
    }
    
    public boolean saveLocalidad(String codigo,String password,String json){
        NodoGrafo busqueda = buscarNodo(codigo);
        if(busqueda!=null && busqueda.obtenerPassword().equals(password)){//validar la operacion
            FileWriter fichero = null;
            try {
                fichero = new FileWriter("C:\\Users\\ebp\\Documents\\NetBeansProjects\\P2Servidor\\build\\web\\fonts\\"+busqueda.archivo);
                fichero.write(json);
                fichero.close();
                return true;
            } catch (IOException e) {
                System.out.println(e.getMessage());
            }
            return true;
        }
        return false;
    }
    
    public boolean addNodo(String nombre,String codigo,String password,double latitud,double longitud){
        int size = nodos.size();
        for (int i = 0; i < size; i++) {
            if(nodos.get(i).getCodigo().equals(codigo))
                return false;
        }        
        nodos.add(new NodoGrafo(nombre, codigo, latitud, longitud, password));            
        return true;
    }    
    
    public boolean deleteNodo(String codigo){
        int size = nodos.size();
        for (int i = 0; i < size; i++) {
            if(nodos.get(i).getCodigo().equals(codigo) && nodos.get(i).estado!=true){
                for (int j = 0; j < size; j++) {
                    nodos.get(j).deleteArista(codigo);
                }
                File fichero = new File("C:\\Users\\ebp\\Documents\\NetBeansProjects\\P2Servidor\\build\\web\\fonts\\"+nodos.get(i).archivo);  
                fichero.delete();
                nodos.remove(nodos.get(i));
                return true;
            }
        }
        return false;
    }
    
    public NodoGrafo buscarNodo(String codigo){
        int size = nodos.size();
        for (int i = 0; i < size; i++) {
            if(nodos.get(i).getCodigo().equals(codigo)){                
                return nodos.get(i);
            }
        }
        return null;
    }
    
    public boolean actualizarNodo(String codigo,String nombre,String password,double latitud,double longitud){
        int size = nodos.size();
        for (int i = 0; i < size; i++) {
            if(nodos.get(i).getCodigo().equals(codigo)){
                nodos.get(i).setNombre(nombre);
                nodos.get(i).establecerPassword(password);
                nodos.get(i).setLat(latitud);
                nodos.get(i).setLng(longitud);
                return true;
            }
        }
        return false;
    }        
    
    public boolean addArista(String codigo,String destino,double multiplicador){
        int size = nodos.size();
        for (int i = 0; i < size; i++) {
            if(nodos.get(i).getCodigo().equals(codigo)){
                if(buscarNodo(destino)!=null)
                    return nodos.get(i).addArista(destino, multiplicador);
            }
        }
        return false;
    }
    
    private boolean addCargar(String codigo,String destino,double multiplicador){
        int size = nodos.size();
        for (int i = 0; i < size; i++) {
            if(nodos.get(i).getCodigo().equals(codigo)){                
                return nodos.get(i).addArista(destino, multiplicador);
            }
        }
        return false;
    }
    
    public boolean deleteArista(String codigo,String destino){
        int size = nodos.size();
        for (int i = 0; i < size; i++) {
            if(nodos.get(i).getCodigo().equals(codigo)){
                return nodos.get(i).deleteArista(destino);
            }                
        }
        return false;
    }        
    
    public boolean reloadArista(String codigo,String destino, double multiplicador){
        int size = nodos.size();
        for (int i = 0; i < size; i++) {
            if(nodos.get(i).getCodigo().equals(codigo)){
                return nodos.get(i).reloadDatoArista(destino, multiplicador);
            }
        }
        return false;
    }            
    
    public void graficar(){

        FileWriter fichero = null;
        PrintWriter pw = null;
        try {                        
            fichero = new FileWriter("C:\\Users\\ebp\\Documents\\NetBeansProjects\\P2Servidor\\build\\web\\fonts\\Grafo.txt");
            pw = new PrintWriter(fichero);
            pw.println("Digraph g{");
            pw.println("graph[center=1 ,rankdir=LR];");
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        
        int size = nodos.size();
        if(nodos.isEmpty()){
            pw.println("\"No existen localidades\"");
        }else{
            for (int i = 0; i < size; i++) {                
                pw.println("\""+nodos.get(i).getCodigo()+"\" [shape=Mrecord,label=\""+nodos.get(i).getCodigo()
                        +"|{Nombre: "+nodos.get(i).getNombre()+"\\lLatitud: "+nodos.get(i).getLat()
                        +"\\lLongitud: "+nodos.get(i).getLng()+"}\"];");                                
                int size2 = nodos.get(i).getAristas().size();
                for (int j = 0; j < size2; j++) {
                    pw.println("\""+nodos.get(i).getCodigo()+"\" -> \""+nodos.get(i).getAristas().get(j).getDestino()+"\""
                            +" [label = \""+nodos.get(i).getAristas().get(j).getMultiplicador()+"\"];");
                }
            }
        }        
        pw.println("}");        
        if(null!= fichero ){
            try {                
                fichero.close();
                Graphviz grafica = new Graphviz();
                grafica.generarGrafica("Grafo.txt", "Grafo");
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
        }        
    }
    
    private String csv(){
        String contenido = "";
        if(!nodos.isEmpty()){
            for (int i = 0; i < nodos.size(); i++) {
                contenido += nodos.get(i).getCodigo()+","+nodos.get(i).getNombre()+","+nodos.get(i).obtenerPassword()+","+
                            nodos.get(i).getLat()+","+nodos.get(i).getLng()+","+nodos.get(i).archivo;
                if(!nodos.get(i).aristas.isEmpty()){//tiene aristas
                    for (int j = 0; j < nodos.get(i).aristas.size(); j++) {
                        contenido += ","+nodos.get(i).getAristas().get(j).getDestino()+","+nodos.get(i).getAristas().get(j).getMultiplicador();
                    }
                }                
                contenido += "\n";
            }
        }        
        return contenido;
    }
    
    public void cargarGrafo(){
        File fichero = new File("C:\\Users\\ebp\\Documents\\NetBeansProjects\\P2Servidor\\build\\web\\fonts\\Grafo.csv");
        Scanner s = null;        
        try {
            s = new Scanner(fichero);
            Encriptacion descifrar = new Encriptacion();            
            while(s.hasNextLine()){                
                String descifrado = descifrar.cF_dF(s.nextLine());
                
                String datoNodo [] = descifrado.split(",");
                int size = datoNodo.length;
                if(size>=6){//asegurarse que venga por lo menos los datos del nodo                   
                    addNodo(datoNodo[1],datoNodo[0],datoNodo[2],Double.valueOf(datoNodo[3]),Double.valueOf(datoNodo[4]));                    
                    for (int i = 6; i < size; i+=2) {
                        addCargar(datoNodo[0], datoNodo[i], Double.valueOf(datoNodo[i+1]));                           
                    }                                    
                }                                                                            
            }
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        }finally{
            try {
                if(s!=null)
                    s.close();
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
    }
    
    public void saveGrafo(){
        FileWriter fichero = null;
        try {
            Encriptacion cifrar = new Encriptacion();
            fichero = new FileWriter("C:\\Users\\ebp\\Documents\\NetBeansProjects\\P2Servidor\\build\\web\\fonts\\Grafo.csv");            
            String cifrado = cifrar.cF_dF(csv());;
            fichero.write(cifrado);
            fichero.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
    
    /*--------------------------------------------GETTER AND SETTER---------------------------------------------------*/

    public ArrayList<NodoGrafo> getNodos() {
        return nodos;
    }

    public void setNodos(ArrayList<NodoGrafo> nodos) {
        this.nodos = nodos;
    }
    
    
    
}
