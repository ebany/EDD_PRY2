/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

/**
 *
 * @author ebp
 */
public class Hilo extends Thread{
    private boolean corriendo = true;

    public void setCorriendo(boolean corriendo) {
        this.corriendo = corriendo;
    }

    @Override
    public void run() {
        while(corriendo){
            try {
                Thread.sleep(40000);
                System.out.println("Hola");
            } catch (InterruptedException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }
    
    
}
