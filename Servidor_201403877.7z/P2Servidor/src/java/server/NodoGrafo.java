/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.io.File;
import java.util.ArrayList;
import java.io.FileWriter;

/*
 
    Es un día hermoso, aprovechalo!
 
 */
public class NodoGrafo {

    private String nombre,codigo,password;
    String archivo;
    private double latitud,longitud;
    ArrayList<AristaGrafo> aristas;
    boolean estado;

    public NodoGrafo(String nombre, String codigo, double latitud, double longitud, String password) {
        this.nombre = nombre;
        this.codigo = codigo;
        this.latitud = latitud;
        this.longitud = longitud;
        this.password = password;
        
        //no se reciben datos para estos elementos, solo se inicializan.
        this.aristas = new ArrayList<>();        
        this.archivo = crearArchivo();
        this.estado = false;
    }        

    public NodoGrafo() {
        this("default","default",0.00,0.00,"default");
    }
        
    
    /*------------------------------------------------------------------------------------------------*/
    
    //Metodo para crear archivo json vacio con nombre del nodo creado
    private String crearArchivo(){
        String ruta = this.codigo + ".json";   
        
        File ver = new File("C:\\Users\\ebp\\Documents\\NetBeansProjects\\P2Servidor\\build\\web\\fonts\\"+ruta);
        if(!ver.exists()){
            FileWriter fichero = null;        
            try {
                fichero = new FileWriter("C:\\Users\\ebp\\Documents\\NetBeansProjects\\P2Servidor\\build\\web\\fonts\\"+ruta);
                fichero.close();
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }                        
        return ruta;
    }
        
    //agregacion de un elemento a la lista de aristas
    public boolean addArista(String destino,double multiplicador){
        //si es el codigo es el mismo del nodo, no se agrega
        if(!destino.equals(this.codigo)){
            if(!aristas.isEmpty()){            
                int size = aristas.size();
                //busqueda para verificar si existe ya la arista            
                for (int i = 0; i < size; i++) {
                    //si ya existe la arista no se añade el elemento.
                    if(aristas.get(i).getDestino().equals(destino)){
                        return false;
                    }
                }
                //no existe en el arreglo de aristas
                aristas.add(new AristaGrafo(destino,multiplicador));
                return true;
            }else{
                aristas.add(new AristaGrafo(destino,multiplicador));
                return true;
            }
        }
        return false;
    }
    
    /* -------------*/
    /*SI SE ACTUALIZA O ELIMINA UN NODOGRAFO, LLAMAR A ESTOS METODOS, SEGUN SEA EL CASO*/
    /* -------------*/
    
    //actualizacion de nombre o multiplicador de un nodo y por consecuencia los datos en aristas
    public boolean reloadDatoArista(String actualD,double nuevoM){
        int size = aristas.size();        
        for (int i = 0; i < size; i++) {
            if(aristas.get(i).getDestino().equals(actualD) ){                
                aristas.get(i).setMultiplicador(nuevoM);
                return true;
            }
        }
        return false;
    }
    
    //eliminacion de una arista. Sea por que se elimina como arista o porque se elima el nodo.
    public boolean deleteArista(String destino){
        int size = aristas.size();
        for (int i = 0; i < size; i++) {
            if (aristas.get(i).getDestino().equals(destino)) {
                aristas.remove(aristas.get(i));
                return true;
            }
        }
        return false;
    }
    
    /*----------------------------------------------- GETTTER AND SETTER ----------------------------------------*/

    public String obtenerPassword() {
        return password;
    }

    public void establecerPassword(String password) {
        this.password = password;
    }
    
    
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public double getLat() {
        return latitud;
    }

    public void setLat(double latitud) {
        this.latitud = latitud;
    }

    public double getLng() {
        return longitud;
    }

    public void setLng(double longitud) {
        this.longitud = longitud;
    }

    public ArrayList<AristaGrafo> getAristas() {
        return aristas;
    }

    public void setAristas(ArrayList<AristaGrafo> aristas) {
        this.aristas = aristas;
    }
    
}
