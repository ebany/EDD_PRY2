/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

/**
 *
 * @author ebp
 */
public class Prueba {
    String codigo,password;

    public Prueba(String codigo, String password) {
        this.codigo = codigo;
        this.password = password;
    }

    public Prueba() {
        this("default","defaults");
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    
    
}
