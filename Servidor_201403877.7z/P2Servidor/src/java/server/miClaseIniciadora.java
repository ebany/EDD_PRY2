/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;


/**
 *
 * @author ebp
 */
public class miClaseIniciadora implements ServletContextListener{

    private Hilo hilo;
    
    @Override
    public void contextInitialized(ServletContextEvent sce) {
        System.out.println("Inicio Servidor");
        ArbolBAst arbol = ArbolBAst.getArbol();
        arbol.cargarArbol();
        Grafo grafo = Grafo.getGrafo();
        grafo.cargarGrafo();
        this.hilo = new Hilo();
        hilo.start();
        grafo.graficar();
        arbol.graficar();
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        this.hilo.setCorriendo(false);
        ArbolBAst arbol = ArbolBAst.getArbol();
        arbol.saveArbol();
        Grafo grafo = Grafo.getGrafo();
        grafo.saveGrafo();
        System.out.println("Finalizo Servidor");
    }
    
}
