/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author ebp
 * 
 * M es el orden del arbol
 * La raiz acepta M claves
 * Los hijos aceptan M - 1 claves
 * La raiz tiene M + 1 hijos y los nodos M
 */
public class ArbolBAst {
   
    private static ArbolBAst arbol = null;

    public static ArbolBAst getArbol() {
        synchronized(Grafo.class){
            if(arbol == null){
                arbol = new ArbolBAst();
            }
        }
        return arbol;
    }
    
    private int orden;
    NodoB raiz = null;

    public ArbolBAst() {
        this.orden = 6;
    }

    /*----------------------------------------------------------------------------*/
    
    public boolean addElemento(String identificacion, String nombre, String apellido,String voucher,String fecha,double monto) throws ParseException{
        
        if(raiz!=null){//hay elementos
            Donacion busqueda = BusquedaNodo(raiz, identificacion);
            if(busqueda!=null){//ya existe la clave
                busqueda.addDatos(voucher, fecha, monto);
                return true;
            }else{//no existe la clave, agregar en arbolB                
                NodoB respuesta = agregarAux(raiz, new Donacion(identificacion,nombre,apellido,voucher,fecha,monto));
                if(respuesta!=null && respuesta.cambio){                    
                    if(respuesta.sizeInfo>this.orden){
                        NodoB datoA = new NodoB();
                        NodoB datoB = new NodoB();
                        NodoB datoC = new NodoB();
                        datoA.sizeInfo++;
                        datoA.sizeHijos = 2;                        
                        datoA.informacion.add(respuesta.informacion.get(3));
                        datoB.sizeInfo = datoC.sizeInfo = 3;                        
                        datoB.informacion.add(respuesta.informacion.get(0));
                        datoB.informacion.add(respuesta.informacion.get(1));
                        datoB.informacion.add(respuesta.informacion.get(2));
                        datoC.informacion.add(respuesta.informacion.get(4));
                        datoC.informacion.add(respuesta.informacion.get(5));
                        datoC.informacion.add(respuesta.informacion.get(6));
                        datoB.sizeHijos = datoC.sizeHijos = 4;
                        datoB.hijos.add(respuesta.hijos.get(0));
                        datoB.hijos.add(respuesta.hijos.get(1));
                        datoB.hijos.add(respuesta.hijos.get(2));
                        datoB.hijos.add(respuesta.hijos.get(3));
                        datoC.hijos.add(respuesta.hijos.get(4));
                        datoC.hijos.add(respuesta.hijos.get(5));
                        datoC.hijos.add(respuesta.hijos.get(6));
                        datoC.hijos.add(respuesta.hijos.get(7));
                        datoA.esRaiz = true;
                        datoA.hijos.add(datoB);
                        datoA.hijos.add(datoC);
                        this.raiz = datoA;
                    }else{
                        this.raiz = respuesta;
                        this.raiz.cambio = false;
                        this.raiz.esRaiz = true;
                    }                                        
                }
                return true;
            }
        }else{//no hay elementos, crear NodoB y agregar clave
            raiz = new NodoB();
            raiz.esRaiz = true;
            raiz.informacion.add(new Donacion(identificacion,nombre,apellido,voucher,fecha,monto));
            raiz.sizeInfo++;
            return true;
        }                
    }    
    
    private NodoB agregarAux(NodoB actual,Donacion nuevo){
        int size = actual.sizeInfo;
        if(actual.sizeHijos==0){//no hay hijos, agregar en este nodo
            actual.informacion.add(nuevo);
            actual.sizeInfo++;
            ordenarClaves(actual);
            //verificacion de exceso de tamanio de claves
            if(actual.esRaiz){//es la raiz, limite orden
                if(actual.sizeInfo>this.orden){
                    NodoB nuevoR = new NodoB();
                    NodoB nuevoI = new NodoB();
                    NodoB nuevoD = new NodoB();
                    nuevoR.sizeInfo++;
                    nuevoR.sizeHijos = 2;
                    nuevoR.informacion.add(actual.informacion.get(3));
                    nuevoI.sizeInfo = nuevoD.sizeInfo = 3;
                    nuevoI.informacion.add(actual.informacion.get(0));
                    nuevoI.informacion.add(actual.informacion.get(1));
                    nuevoI.informacion.add(actual.informacion.get(2));
                    nuevoD.informacion.add(actual.informacion.get(4));
                    nuevoD.informacion.add(actual.informacion.get(5));
                    nuevoD.informacion.add(actual.informacion.get(6));
                    nuevoR.hijos.add(nuevoI);
                    nuevoR.hijos.add(nuevoD);
                    nuevoR.cambio = true;
                    return nuevoR;
                }
            }else{//no es la raiz, limite orden - 1
                if(actual.sizeInfo>this.orden-1){
                    actual.cambio = true;
                    return actual;
                }
            }            
            if(actual.sizeInfo>=this.orden)
                actual.cambio = true;            
            return actual;
        }else{//si hay hijos, ver donde agregar
            for (int i = 0; i < size; i++) { //recorrer las claves y determinar donde agregar
                if(actual.informacion.get(i).getIdentificacion().compareTo(nuevo.getIdentificacion())>0){//a>b
                    NodoB respuesta = agregarAux(actual.hijos.get(i), nuevo);                    
                    if(respuesta.cambio){//realizar modificacion
                        //if(respuesta.sizeHijos==0){//nodo hoja que hay que tratar de redistribuir o subir a la raiz
                            if(actual.hijos.get(i+1).sizeInfo<this.orden-1){//aun hay espacio en el hermano derecho, REDESTRIBUCION                               
                                actual.hijos.get(i+1).informacion.add(actual.informacion.get(i));
                                actual.informacion.set(i, respuesta.informacion.get(5));
                                respuesta.informacion.remove(5);                               
                                respuesta.sizeInfo--;
                                actual.hijos.get(i+1).sizeInfo++;
                                ordenarClaves(actual.hijos.get(i+1));
                                /*-------HIJOS DE HIJOS----*/
                                if (!actual.hijos.get(i).hijos.isEmpty()) {//el hijo tiene hijos
                                    actual.hijos.get(i+1).hijos.add(0, actual.hijos.get(i).hijos.get(6));
                                    actual.hijos.get(i+1).sizeHijos++;
                                    actual.hijos.get(i).hijos.remove(6);
                                    actual.hijos.get(i).sizeHijos--;
                                }
                                /*-----------*/
                                respuesta.cambio = false;
                                return respuesta;
                            }else if(i!=0 && actual.hijos.get(i-1).sizeInfo<this.orden-1){//aun hay espacio en el hermano izquierdo, REDESTRIBUCION 
                                actual.hijos.get(i-1).informacion.add(actual.informacion.get(i-1));
                                actual.informacion.set(i-1, respuesta.informacion.get(0));
                                respuesta.informacion.remove(0);                               
                                respuesta.sizeInfo--;
                                actual.hijos.get(i-1).sizeInfo++;
                                ordenarClaves(actual.hijos.get(i-1));
                                /*----HIJOS DE HIJOS----*/
                                if (!actual.hijos.get(i).hijos.isEmpty()) {//el hijo tiene hijos
                                    actual.hijos.get(i-1).hijos.add(actual.hijos.get(i).hijos.get(0));
                                    actual.hijos.get(i-1).sizeHijos++;
                                    actual.hijos.get(i).hijos.remove(0);
                                    actual.hijos.get(i).sizeHijos--;
                                }
                                /*----------*/
                                respuesta.cambio = false;
                                return respuesta;
                            }else{//verificar si padre esta lleno                                                                                            
                                    //no esta lleno, crear nuevo hijo, division 3                                    
                                ArrayList<Donacion> split = new ArrayList<>();
                                //agrego hijo izquierda
                                for (int j = 0; j < actual.hijos.get(i).sizeInfo; j++) {
                                    split.add(actual.hijos.get(i).informacion.get(j));                                            
                                }
                                //agrego clave padre
                                split.add(actual.informacion.get(i));                                
                                //agrego hijo derecha
                                for (int j = 0; j < actual.hijos.get(i+1).sizeInfo; j++) {
                                    split.add(actual.hijos.get(i+1).informacion.get(j));                                            
                                }      
                                
                                //creacion de nuevos hijos
                                NodoB aux1 = new NodoB();
                                NodoB aux2 = new NodoB();
                                NodoB aux3 = new NodoB();
                                aux1.sizeInfo = 4;
                                aux2.sizeInfo = aux3.sizeInfo = 3;
                                aux1.informacion.add(split.get(0));
                                aux1.informacion.add(split.get(1));
                                aux1.informacion.add(split.get(2));
                                aux1.informacion.add(split.get(3));
                                aux2.informacion.add(split.get(5));
                                aux2.informacion.add(split.get(6));
                                aux2.informacion.add(split.get(7));
                                aux3.informacion.add(split.get(9));
                                aux3.informacion.add(split.get(10));
                                aux3.informacion.add(split.get(11));
                                //añadir claves
                                actual.informacion.add(split.get(4));
                                actual.informacion.add(split.get(8));
                                
                                /*-----HIJOS DE HIJOS-------*/                                
                                if(!actual.hijos.get(i).hijos.isEmpty() ){                                    
                                    ArrayList<NodoB> descendientes = new ArrayList<>();
                                    for (int j = 0; j < actual.hijos.get(i).hijos.size(); j++) {
                                        descendientes.add(actual.hijos.get(i).hijos.get(j));
                                    }
                                    for (int j = 0; j < actual.hijos.get(i+1).hijos.size(); j++) {
                                        descendientes.add(actual.hijos.get(i+1).hijos.get(j));
                                    }
                                    aux1.hijos.add(descendientes.get(0));
                                    aux1.hijos.add(descendientes.get(1));
                                    aux1.hijos.add(descendientes.get(2));
                                    aux1.hijos.add(descendientes.get(3));
                                    aux1.hijos.add(descendientes.get(4));
                                    aux1.sizeHijos = 5;
                                    aux2.hijos.add(descendientes.get(5));
                                    aux2.hijos.add(descendientes.get(6));
                                    aux2.hijos.add(descendientes.get(7));
                                    aux2.hijos.add(descendientes.get(8));
                                    aux2.sizeHijos = 4;
                                    aux3.hijos.add(descendientes.get(9));
                                    aux3.hijos.add(descendientes.get(10));
                                    aux3.hijos.add(descendientes.get(11));
                                    aux3.hijos.add(descendientes.get(12));
                                    aux3.sizeHijos = 4;
                                }
                                /*------------*/
                                
                                //eliminar
                                actual.informacion.remove(i);
                                actual.hijos.set(i, aux1);
                                actual.hijos.set(i+1, aux2);
                                actual.hijos.add(i+2, aux3);                                                                
                                
                                //actualizacion datos actual                                                                
                                actual.sizeInfo++;
                                actual.sizeHijos++;
                                if(actual.sizeInfo>=this.orden)
                                    actual.cambio = true;
                                else
                                    actual.cambio = false;
                                ordenarClaves(actual);
                                return actual;                                   
                            }                     
                    }
                    return respuesta;
                }else if(i==size-1 && actual.informacion.get(i).getIdentificacion().compareTo(nuevo.getIdentificacion())<0){//es la ultima posicion y id es mayor
                    NodoB respuesta = agregarAux(actual.hijos.get(i+1), nuevo);
                    if(respuesta.cambio){//realizar modificacion
                        //if(respuesta.sizeHijos==0){//nodo hoja que hay que tratar de redistribuir o subir a la raiz
                            if(actual.hijos.get(i).sizeInfo<this.orden-1){//aun hay espacio en el hermano izquierdo, REDESTRIBUCION
                                actual.hijos.get(i).informacion.add(actual.informacion.get(i));
                                actual.informacion.set(i, respuesta.informacion.get(0));
                                respuesta.informacion.remove(0);                               
                                respuesta.sizeInfo--;
                                actual.hijos.get(i).sizeInfo++;
                                ordenarClaves(actual.hijos.get(i));
                                /*-------HIJOS DE HIJOS----*/
                                if (!actual.hijos.get(i).hijos.isEmpty()) {//el hijo tiene hijos
                                    actual.hijos.get(i).hijos.add(actual.hijos.get(i+1).hijos.get(0));
                                    actual.hijos.get(i).sizeHijos++;
                                    actual.hijos.get(i+1).hijos.remove(0);
                                    actual.hijos.get(i+1).sizeHijos--;
                                }
                                /*-----------*/
                                respuesta.cambio = false;
                                return respuesta;
                            }else{//verificar si padre esta lleno                                                               
                                //crear nuevo hijo, division 3  
                                ArrayList<Donacion> split = new ArrayList<>();
                                //agrego hijo izquierda
                                for (int j = 0; j < actual.hijos.get(i).sizeInfo; j++) {
                                    split.add(actual.hijos.get(i).informacion.get(j));                                            
                                }
                                //agrego clave padre
                                split.add(actual.informacion.get(i));
                                //agrego hijo derecha
                                for (int j = 0; j < actual.hijos.get(i+1).sizeInfo; j++) {
                                    split.add(actual.hijos.get(i+1).informacion.get(j));                                            
                                }                                                                               
                                //creacion de nuevos hijos
                                NodoB aux1 = new NodoB();
                                NodoB aux2 = new NodoB();
                                NodoB aux3 = new NodoB();
                                aux1.sizeInfo = 4;
                                aux2.sizeInfo = aux3.sizeInfo = 3;
                                aux1.informacion.add(split.get(0));
                                aux1.informacion.add(split.get(1));
                                aux1.informacion.add(split.get(2));
                                aux1.informacion.add(split.get(3));
                                aux2.informacion.add(split.get(5));
                                aux2.informacion.add(split.get(6));
                                aux2.informacion.add(split.get(7));
                                aux3.informacion.add(split.get(9));
                                aux3.informacion.add(split.get(10));
                                aux3.informacion.add(split.get(11));
                                //añadir claves
                                actual.informacion.add(split.get(4));
                                actual.informacion.add(split.get(8));
                                
                                /*-----HIJOS DE HIJOS-------*/                                
                                if(!actual.hijos.get(i).hijos.isEmpty() ){                                    
                                    ArrayList<NodoB> descendientes = new ArrayList<>();
                                    for (int j = 0; j < actual.hijos.get(i).hijos.size(); j++) {
                                        descendientes.add(actual.hijos.get(i).hijos.get(j));
                                    }
                                    for (int j = 0; j < actual.hijos.get(i+1).hijos.size(); j++) {
                                        descendientes.add(actual.hijos.get(i+1).hijos.get(j));
                                    }
                                    aux1.hijos.add(descendientes.get(0));
                                    aux1.hijos.add(descendientes.get(1));
                                    aux1.hijos.add(descendientes.get(2));
                                    aux1.hijos.add(descendientes.get(3));
                                    aux1.hijos.add(descendientes.get(4));
                                    aux1.sizeHijos = 5;
                                    aux2.hijos.add(descendientes.get(5));
                                    aux2.hijos.add(descendientes.get(6));
                                    aux2.hijos.add(descendientes.get(7));
                                    aux2.hijos.add(descendientes.get(8));
                                    aux2.sizeHijos = 4;
                                    aux3.hijos.add(descendientes.get(9));
                                    aux3.hijos.add(descendientes.get(10));
                                    aux3.hijos.add(descendientes.get(11));
                                    aux3.hijos.add(descendientes.get(12));
                                    aux3.sizeHijos = 4;
                                }
                                /*------------*/
                                
                                //eliminar
                                actual.informacion.remove(i);
                                actual.hijos.set(i, aux1);
                                actual.hijos.set(i+1, aux2);
                                actual.hijos.add(i+2, aux3);
                                //actualizacion datos actual                                
                                actual.sizeInfo++;
                                actual.sizeHijos++;
                                if(actual.sizeInfo>=this.orden)
                                    actual.cambio = true;
                                else
                                    actual.cambio = false;
                                ordenarClaves(actual);
                                return actual;
                            }                        
                    }
                    return respuesta;
                }
            }
        }        
        return null;
    }
    
    private void ordenarClaves(NodoB actual){
        int size = actual.sizeInfo;
        Donacion aux = null;
        for (int i = 0; i < size-1; i++) {
            for (int j = i+1; j < size; j++) {
                // a > b
                if(actual.informacion.get(i).getIdentificacion().compareTo(actual.informacion.get(j).getIdentificacion())>0){
                    aux = actual.informacion.get(i);
                    actual.informacion.set(i,actual.informacion.get(j));
                    actual.informacion.set(j, aux);
                }
            }
        }
    }
    
    public Donacion BusquedaNodo(NodoB actual, String id){//enviar raiz y codigo de usuario
        int size = actual.sizeInfo;
        for (int i = 0; i < size; i++) {
            if(actual.informacion.get(i).getIdentificacion().compareTo(id)>0){//a > b
                if(actual.sizeHijos!=0){//verificacion que si tenga hijos
                    return BusquedaNodo(actual.hijos.get(i), id);
                }                
            }else if(actual.informacion.get(i).getIdentificacion().equals(id)){
                return actual.informacion.get(i);
            }else if(i==size-1 && actual.informacion.get(i).getIdentificacion().compareTo(id)<0){//es la ultima posicion y id es mayor
                if(actual.sizeHijos!=0){//verificacion que si tenga hijos
                    return BusquedaNodo(actual.hijos.get(i+1),id);
                }
            }
        }
        return null;
    }
    
    public void graficar(){
        FileWriter fichero = null;
        PrintWriter pw = null;
        try {                        
            fichero = new FileWriter("C:\\Users\\ebp\\Documents\\NetBeansProjects\\P2Servidor\\build\\web\\fonts\\ArbolB.txt");
            pw = new PrintWriter(fichero);
            pw.println("Digraph g{");
            pw.println("rankdir = TB");
            pw.println("node[shape=record];");
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        
        if(this.raiz==null){
            pw.println("\"No existen Donaciones economicas.(Codos >:v)\"");
        }else{        
            ArrayList<NodoB> pila = new ArrayList<>();
            pila.add(raiz);
            int contadorH = 0;
            int contadorL = 0;
            while(!pila.isEmpty()){
                int size = pila.size();      
                int auxC = 0;
                //graficar pagina con enlace a nodos hijos
                for (int i = 0; i < size; i++) {
                    pw.print("\"pagina"+contadorL+"c"+contadorH+"\" [shape=record,label=\"");                    
                    int size2 = pila.get(i).getInformacion().size();                    
                    for (int j = 0; j < size2; j++) {
                        pw.print("{Clave: "+pila.get(i).getInformacion().get(j).getIdentificacion()+"\\lN: "+
                            pila.get(i).getInformacion().get(j).getNombre()+"\\lA: "+pila.get(i).getInformacion().get(j).getApellido()
                            + "\\l|{");                        
                        
                        int size3 = pila.get(i).getInformacion().get(j).getLista().size();
                        pw.print("Fecha:\\l");
                        for (int k = 0; k < size3; k++) {                            
                            pw.print(pila.get(i).getInformacion().get(j).getLista().get(k).getFecha()+"***"+
                                    pila.get(i).getInformacion().get(j).getLista().get(k).getMonto()+"\\l");                            
                        }
                        if(j==size2-1)
                            pw.print("}}");
                        else
                            pw.print("}}|");
                    }
                    pw.println("\"];");                    
                    if(pila.get(i).sizeHijos!=0){                        
                        for (int j = 0; j < pila.get(i).sizeInfo; j++) {
                            pw.println("\"pagina"+contadorL+"c"+i+"\" -> \"pagina"+(contadorL+1)+"c"+(j+ auxC)+"\";");
                            pw.println("\"pagina"+contadorL+"c"+i+"\" -> \"pagina"+(contadorL+1)+"c"+(j + 1 +auxC)+"\";");                              
                        }                                                                                        
                        auxC += pila.get(i).sizeInfo + 1;
                    }
                    contadorH++;
                }
                //agregar nodos hijos
                for (int i = 0; i < size; i++) {
                    if(pila.get(i).sizeHijos!=0){
                        int size4 = pila.get(i).sizeHijos;
                        for (int j = 0; j < size4; j++) {
                            pila.add(pila.get(i).getHijos().get(j));
                        }
                    }
                }
                //quitar padres                
                for (int i = size-1; i >=0; i--) {
                    pila.remove(i);
                }
                //aumentos y decrementos
                contadorL++;
                contadorH = 0;                
            }
        }
        
        
        pw.println("}");
        if(null!= fichero ){
            try {
                fichero.close();
                Graphviz grafica = new Graphviz();
                grafica.generarGrafica("ArbolB.txt", "ArbolB");
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }

    private String csv(){
        String datos = "";
        if(this.raiz!=null){
            ArrayList<NodoB> pila = new ArrayList<>();
            pila.add(raiz);
            while(!pila.isEmpty()){
                int size = pila.size();
                for (int i = 0; i < size; i++) {
                    int size2 = pila.get(i).sizeInfo;
                    for (int j = 0; j < size2; j++) {
                        Donacion info = pila.get(i).informacion.get(j);
                        int size3 = info.lista.size();
                        for (int k = 0; k < size3; k++) {
                            datos += info.getIdentificacion()+","+info.getNombre()+","+info.getApellido()+","+info.lista.get(k).getFecha()+
                                    ","+info.lista.get(k).getMonto()+","+info.lista.get(k).getVoucher()+"\n";
                        }
                    }
                }
                //agregar nodos hijos
                for (int i = 0; i < size; i++) {
                    if(pila.get(i).sizeHijos!=0){
                        int size4 = pila.get(i).sizeHijos;
                        for (int j = 0; j < size4; j++) {
                            pila.add(pila.get(i).getHijos().get(j));
                        }
                    }
                }
                //quitar padres                
                for (int i = size-1; i >=0; i--) {
                    pila.remove(i);
                }                
            }
        }                
        return datos;
    }
    
    public void saveArbol(){
        FileWriter fichero = null;
        try {
            Encriptacion cifrar = new Encriptacion();
            fichero = new FileWriter("C:\\Users\\ebp\\Documents\\NetBeansProjects\\P2Servidor\\build\\web\\fonts\\ArbolB.csv");
            String cifrado = cifrar.cF_dF(csv());
            fichero.write(cifrado);
            fichero.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
    
    public void cargarArbol(){
        File fichero = new File("C:\\Users\\ebp\\Documents\\NetBeansProjects\\P2Servidor\\build\\web\\fonts\\ArbolB.csv");
        Scanner s = null;  
        try {
            s = new Scanner(fichero);
            Encriptacion descifrar = new Encriptacion();            
            while(s.hasNextLine()){
                String descifrado = descifrar.cF_dF(s.nextLine());
                
                String datoNodo [] = descifrado.split(",");
                int size = datoNodo.length;
                if(size==6){//validar que vengan los datos completos
                    addElemento(datoNodo[0], datoNodo[1], datoNodo[2], datoNodo[5], datoNodo[3], Double.valueOf(datoNodo[4]));
                }
            }
        } catch (FileNotFoundException | NumberFormatException | ParseException e) {
            System.out.println(e.getMessage());
        }finally{
            try {
                if(s!=null)
                    s.close();
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
    }
    
    /*----------------------------------GETTER------------------------------------*/
    
    public NodoB getRaiz() {
        return raiz;
    }

}
