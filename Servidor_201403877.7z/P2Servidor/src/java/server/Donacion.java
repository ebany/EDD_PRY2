/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ArrayList;

/**
 *
 * @author ebp
 */
public class Donacion {
    
    private String identificacion,nombre,apellido;
    ArrayList<DatosDonacion> lista;

    public Donacion(String identificacion, String nombre, String apellido,String voucher,String fecha,double monto){
        this.identificacion = identificacion;
        this.nombre = nombre;
        this.apellido = apellido;
        this.lista = new ArrayList<>();
        this.lista.add(new DatosDonacion(voucher,fecha,monto));
    }
    
    public boolean addDatos(String voucher,String fecha,double monto) throws ParseException{
        this.lista.add(new DatosDonacion(voucher,fecha,monto));
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        DatosDonacion aux = null;
        int size = this.lista.size();
        for (int i = 0; i < size -1; i++) {
            for (int j = i+1; j < size; j++) {
                Date date1 = sdf.parse(this.lista.get(i).getFecha());
                Date date2 = sdf.parse(this.lista.get(j).getFecha());
                if(date1.compareTo(date2)>0){
                    aux = this.lista.get(i);                    
                    this.lista.set(i, this.lista.get(j));
                    this.lista.set(j, aux);                    
                }
            }
        }        
        return true;
    }
    

    public Donacion() {
        this("000","default","default","default","default",0.00);
    }            

    public String getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(String identificacion) {
        this.identificacion = identificacion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public ArrayList<DatosDonacion> getLista() {
        return lista;
    }

    public void setLista(ArrayList<DatosDonacion> lista) {
        this.lista = lista;
    }
    
    
    
}
