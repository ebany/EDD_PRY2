/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

/**
 *
 * @author ebp
 */
public class DatosDonacion {
    
    String voucher,fecha;
    double monto;

    public DatosDonacion(String voucher, String fecha, double monto) {
        this.voucher = voucher;
        this.fecha = fecha;
        this.monto = monto;
    }

    public DatosDonacion() {
        this("default","default",0.00);
    }

    public String getVoucher() {
        return voucher;
    }

    public void setVoucher(String voucher) {
        this.voucher = voucher;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }
    
    
    
}
