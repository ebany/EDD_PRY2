/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

/**
 *
 * @author CodigoG
 */
public class Encriptacion {
    
    String cF_dF(String texto){
        
        String nuevo = "";        
        char arreglo[] = texto.toCharArray();
        int tamanio = arreglo.length;
        int auxI;
        char auxC = ' ';
        for (int i = 0; i < tamanio; i++) {                             
            if(arreglo[i]>=32 && arreglo[i]<=41){//10-5
                if(arreglo[i]<=36){
                    auxI = arreglo[i] + 5;
                    auxC = (char)auxI;                    
                }else{
                    auxI = arreglo[i] - 5;
                    auxC = (char)auxI;
                }                
            }else if(arreglo[i]>=42 && arreglo[i]<=69){//28-14
                if(arreglo[i]<=55){
                    auxI = arreglo[i] + 14;
                    auxC = (char)auxI;
                }else{
                    auxI = arreglo[i] - 14;
                    auxC = (char)auxI;
                }
            }else if(arreglo[i]>=70 && arreglo[i]<=89){//20-10
                if(arreglo[i]<=79){
                    auxI = arreglo[i] + 10;
                    auxC = (char)auxI;
                }else{
                    auxI = arreglo[i] - 10;
                    auxC = (char)auxI;
                }
            }else if(arreglo[i]>=90 && arreglo[i]<=95){//6-3
                if(arreglo[i]<=92){
                    auxI = arreglo[i] + 3;
                    auxC = (char)auxI;
                }else{
                    auxI = arreglo[i] - 3;
                    auxC = (char)auxI;
                }
            }else if(arreglo[i]>=96 && arreglo[i]<=107){//12-6
                if(arreglo[i]<=101){
                    auxI = arreglo[i] + 6;
                    auxC = (char)auxI;
                }else{
                    auxI = arreglo[i] - 6;
                    auxC = (char)auxI;
                }
            }else if(arreglo[i]>=108 && arreglo[i]<=125){//18-9                
                if(arreglo[i]<=116){
                    auxI = arreglo[i] + 9;
                    auxC = (char)auxI;
                }else{
                    auxI = arreglo[i] - 9;
                    auxC = (char)auxI;
                }                
            }else if(arreglo[i]>=126 && arreglo[i]<=175){//50-25
                if(arreglo[i]<=150){
                    auxI = arreglo[i] + 25;
                    auxC = (char)auxI;
                }else{
                    auxI = arreglo[i] - 25;
                    auxC = (char)auxI;
                }
            }else if(arreglo[i]>=176 && arreglo[i]<=189){//14-7
                if(arreglo[i]<=182){
                    auxI = arreglo[i] + 7;
                    auxC = (char)auxI;
                }else{
                    auxI = arreglo[i] - 7;
                    auxC = (char)auxI;
                }
            }else if(arreglo[i]>=190 && arreglo[i]<=219){//30-15
                if(arreglo[i]<=204){
                    auxI = arreglo[i] + 15;
                    auxC = (char)auxI;
                }else{
                    auxI = arreglo[i] - 15;
                    auxC = (char)auxI;
                }
            }else if(arreglo[i]>=220 && arreglo[i]<=241){//22-11
                if(arreglo[i]<=230){
                    auxI = arreglo[i] + 11;
                    auxC = (char)auxI;
                }else{
                    auxI = arreglo[i] - 11;
                    auxC = (char)auxI;
                }
            }else if(arreglo[i]>=242 && arreglo[i]<=255){//18-9
                if(arreglo[i]<=248){
                    auxI = arreglo[i] + 7;
                    auxC = (char)auxI;
                }else{
                    auxI = arreglo[i] - 7;
                    auxC = (char)auxI;
                }
            }else{
                auxC = arreglo[i];
            }          
            nuevo+= auxC;
        }        
        
        return nuevo;
    }
    
    String cifrado(String texto){
        String nuevo = "";
        char arreglo[] = texto.toCharArray();
        int tamanio = arreglo.length;
        int auxI;
        char auxC = ' ';
        for (int i = 0; i < tamanio; i++) {
            if(arreglo[i]>=253 && arreglo[i]<=255){
                auxI = 255 - arreglo[i] + 32;  
                auxC = (char)auxI;
            }else{
                if(arreglo[i]>=32 && arreglo[i]<=252){
                    auxI = arreglo[i] + 3;
                    auxC = (char)auxI;
                }else                    
                    auxC = arreglo[i];
            }
            nuevo+= auxC;
        }
        return nuevo;
    }
    
    String descifrado(String texto){
        String nuevo = "";
        char arreglo[] = texto.toCharArray();
        int tamanio = arreglo.length;
        int auxI;
        char auxC = ' ';
        for (int i = 0; i < tamanio; i++) {
            if(arreglo[i]>=32 && arreglo[i]<=34){
                auxI = 34 - arreglo[i] + 253;  
                auxC = (char)auxI;
            }else{
                if(arreglo[i]>=35 && arreglo[i]<=255){
                    auxI = arreglo[i] - 3;
                    auxC = (char)auxI;
                }else                    
                    auxC = arreglo[i];
            }
            nuevo+= auxC;
        }
        return nuevo;
    }
    
}
