/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.text.ParseException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.POST;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * REST Web Service
 *
 * @author ebp
 */
@Path("generic")
public class GenericResource {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of GenericResource
     */
    public GenericResource() {
    }
    
    @GET
    @Path("getGrafo")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getJson() {        
        Grafo grafo = Grafo.getGrafo();
        return Response.ok(grafo.getNodos()).build();
    }
    
    @POST
    @Path("getLocalidad")    
    @Consumes(MediaType.TEXT_PLAIN)
    public Response login(String log) {
        
        Grafo grafo = Grafo.getGrafo();
        String arreglo[] = log.split("@@");        
        String respuesta = "no";
        System.out.println(log);
        if(arreglo.length==2){            
            NodoGrafo busqueda = grafo.buscarNodo(arreglo[0]);
            if(busqueda!=null && busqueda.estado==false){
                respuesta = grafo.obtenerJson(arreglo[0],arreglo[1]);
                if(!respuesta.equals("no")){
                    busqueda.estado = true;
                }
            }
        }                        
        return Response.ok(respuesta).build();
    }
    
    @POST
    @Path("saveLocalidad")
    @Consumes(MediaType.TEXT_PLAIN)
    public Response guardarDatosLocalidad(String texto){
        Grafo grafo = Grafo.getGrafo();        
        String arreglo[] = texto.split("@@");
        String respuesta = "no";
        
        NodoGrafo busqueda = grafo.buscarNodo(arreglo[0]);
        
        if(busqueda!=null && arreglo.length==2){
            if(grafo.saveLocalidad(arreglo[0],busqueda.obtenerPassword(), arreglo[1]))
                respuesta = "si";
        }
        return Response.ok(respuesta).build();
    }
    
    @POST
    @Path("freeLocalidad")
    @Consumes(MediaType.TEXT_PLAIN)
    public Response cerrarSesion(String texto){
        Grafo grafo = Grafo.getGrafo();        
        String respuesta = "no";
        if(!texto.isEmpty()){
            NodoGrafo busqueda = grafo.buscarNodo(texto);
            if(busqueda!=null && busqueda.estado==true){
                busqueda.estado = false;
                respuesta = "si";
            }
        }
        return Response.ok(respuesta).build();
    }
    
    @POST
    @Path("makeDonacion")
    @Consumes(MediaType.TEXT_PLAIN)
    public Response donar(String datos){
        ArbolBAst arbol = ArbolBAst.getArbol();
        String info[] = datos.split("@@");
        String respuesta = "no";
        if(info.length==6){            
            try {
                if(arbol.addElemento(info[0], info[1], info[2], info[3], info[5], Double.valueOf(info[4]))){
                    respuesta = "si";
                }
            } catch (ParseException ex) {
                System.out.println(ex.getMessage());
            }
        }
        return Response.ok(respuesta).build();
    }
    
    @POST
    @Path("getDonaciones")
    @Consumes(MediaType.TEXT_PLAIN)
    @Produces(MediaType.APPLICATION_JSON)
    public Response donante(String usr){
        ArbolBAst arbol = ArbolBAst.getArbol();
        Donacion busqueda = arbol.BusquedaNodo(arbol.raiz, usr);
        if(busqueda!=null){
            return Response.ok(busqueda).build();
        }else
            return Response.ok("no").build();        
    }
}
