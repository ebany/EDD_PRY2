/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.util.ArrayList;

/**
 *
 * @author ebp
 */
public class NodoB {
    
    private int orden;
    int sizeInfo,sizeHijos;    
    ArrayList<Donacion> informacion;
    ArrayList<NodoB> hijos;
    boolean esRaiz;
    boolean cambio;

    public NodoB() {
        this.orden = 6;
        this.sizeInfo = 0;
        this.sizeHijos = 0;
        this.esRaiz = false;        
        this.hijos = new ArrayList<>();
        this.informacion = new ArrayList<>();
        this.cambio = false; // saber si hubo modificacion, separacion y nuevo nivel
    }

    public ArrayList<Donacion> getInformacion() {
        return informacion;
    }

    public void setInformacion(ArrayList<Donacion> informacion) {
        this.informacion = informacion;
    }

    public ArrayList<NodoB> getHijos() {
        return hijos;
    }

    public void setHijos(ArrayList<NodoB> hijos) {
        this.hijos = hijos;
    }
    
}
